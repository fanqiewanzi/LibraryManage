// conf 包提供了设置APP名称的方法。该APP名称会被放入API请求的UserAgent中，方便后续查询日志分析问题。
package conf
