// Qiniu RTC Server API 为七牛实时音视频云提供权限验证和房间管理功能，API 均采用 REST 接口。
// 提供 app 操作接口，包含 CreateApp、GetApp、DeleteApp、UpdateApp ；
// 提供 room 操作接口，包含 ListUser、KickUser、ListActiveRoom 以及
// RoomToken 的计算

package rtc
