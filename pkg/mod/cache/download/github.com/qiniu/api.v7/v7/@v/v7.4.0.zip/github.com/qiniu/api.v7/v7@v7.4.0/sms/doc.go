// Package sms 七牛云短信服务 SDK
// 官网地址： http://www.qiniu.com/products/sms
// 开发者文档： https://developer.qiniu.com/sms
package sms
